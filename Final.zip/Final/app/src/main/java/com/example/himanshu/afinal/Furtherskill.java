package com.example.himanshu.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;



import java.util.ArrayList;

public class Furtherskill extends AppCompatActivity {

    ListView listView;
    private Furtherskill_Adapter adapterMain;
    ArrayList<String> myitems=new ArrayList<>();

    String videos="वीडियो";
    String iti="आईटीआई";
    String govt_schemes="सरकारी योजनाएं";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_furtherskill);
        listView=findViewById(R.id.list);

        myitems.add(videos);
        myitems.add(iti);
        myitems.add(govt_schemes);


        adapterMain=new Furtherskill_Adapter(this,myitems);
        listView.setAdapter(adapterMain);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(myitems.get(i).equals(videos))
                {
                    Intent intent=new Intent(getApplicationContext(),Skill_video.class);
                    startActivity(intent);
                }
                if(myitems.get(i).equals(govt_schemes))
                {
                    Intent intent=new Intent(getApplicationContext(),Govt_schemes.class);
                    startActivity(intent);
                }

            }
        });

    }
}
