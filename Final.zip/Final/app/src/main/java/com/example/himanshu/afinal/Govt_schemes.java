package com.example.himanshu.afinal;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.example.himanshu.afinal.Adapter_Sarkari_Yojana;


import java.util.ArrayList;

public class Govt_schemes extends AppCompatActivity {
    ListView list;
    private Adapter_Sarkari_Yojana adapterSarkariYojana;
    ArrayList<Utilities> arrayList=new ArrayList<>();
    String gramin_vikas_mantralay="ग्रामीण विकास मंत्रालय";
    String krishi_mantralay="कृषि मंत्रालय";
    String grah_mantralay="ग्रह मंत्रालय";
    String kaushal_vikas_mantralay="कौशल विकास मंत्रालय";
    String laghu_udhyog_mantralay="लघु उद्यम मंत्रालय";
    String women_and_child="महिलाओं एवं शिशु मंत्रालय";
    String shiksha_mantralay="शिक्षा मंत्रालय";
    Bitmap women_child ;
    Bitmap krishi;
    Bitmap laghu_udhyog;
    Bitmap home_affairs;
    Bitmap gramin_ministry;
    Bitmap kaushal_ministry;
    Bitmap siksha_mantralay_image;
    Utilities gramin_utility=new Utilities();
    Utilities krishi_utility=new Utilities();
    Utilities laghu_udhog_uthility=new Utilities();
    Utilities home_affair_utility=new Utilities();
    Utilities women_child_utility=new Utilities();
    Utilities kaushal_vikas_utility=new Utilities();
    Utilities shiksha_utility=new Utilities();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt_schemes);

        list = (ListView) findViewById(R.id.list);


        women_child = BitmapFactory.decodeResource(getResources(), R.drawable.women_child);
        krishi=BitmapFactory.decodeResource(getResources(),R.drawable.ministry_of_agriculture);
        laghu_udhyog=BitmapFactory.decodeResource(getResources(),R.drawable.laghu_udhog_ministry);
        home_affairs=BitmapFactory.decodeResource(getResources(),R.drawable.grah_mantalay);
        gramin_ministry=BitmapFactory.decodeResource(getResources(),R.drawable.gramin_ministry);
        kaushal_ministry=BitmapFactory.decodeResource(getResources(),R.drawable.kaushal_ministry);
        siksha_mantralay_image=BitmapFactory.decodeResource(getResources(),R.drawable.education_ministry_logo);

        gramin_utility.setName(gramin_vikas_mantralay);
        gramin_utility.setImage(gramin_ministry);
        krishi_utility.setName(krishi_mantralay);
        krishi_utility.setImage(krishi);
        laghu_udhog_uthility.setName(laghu_udhyog_mantralay);
        laghu_udhog_uthility.setImage(laghu_udhyog);
        shiksha_utility.setName(shiksha_mantralay);
        shiksha_utility.setImage(siksha_mantralay_image);
        kaushal_vikas_utility.setName(kaushal_vikas_mantralay);
        kaushal_vikas_utility.setImage(kaushal_ministry);
        home_affair_utility.setName(grah_mantralay);
        home_affair_utility.setImage(home_affairs);
        women_child_utility.setImage(women_child);
        women_child_utility.setName(women_and_child);

        arrayList.add(gramin_utility);
        arrayList.add(krishi_utility);
        arrayList.add(shiksha_utility);
        arrayList.add(laghu_udhog_uthility);
        arrayList.add(kaushal_vikas_utility);
        arrayList.add(home_affair_utility);
        arrayList.add(women_child_utility);

        adapterSarkariYojana=new Adapter_Sarkari_Yojana(this,arrayList);
        list.setAdapter(adapterSarkariYojana);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                if(arrayList.get(i).getName().equals(gramin_vikas_mantralay))
                {
                    Intent intent=new Intent(getApplicationContext(),GraminMantralay.class);
                    startActivity(intent);
                }
                if(arrayList.get(i).getName().equals(women_and_child))
                {
                    Intent intent=new Intent(getApplicationContext(),WomenChild.class);
                    startActivity(intent);
                }
                if(arrayList.get(i).getName().equals(shiksha_mantralay))
                {
                    Intent intent=new Intent(getApplicationContext(),ShikshaMantralay.class);
                    startActivity(intent);
                }

            }
        });

    }
}
