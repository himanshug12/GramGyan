package com.example.himanshu.afinal;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Web_Beti extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web__beti);

        WebView mywebview = (WebView) findViewById(R.id.webView);
        mywebview.setWebViewClient(new WebViewClient());
         mywebview.loadUrl("https://pradhanmantri-yogana.in/beti-bachao-beti-padhao-scheme-in-hindi/");


    }
}