package com.example.himanshu.afinal;



import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;



import java.util.ArrayList;

public class Shiksha extends AppCompatActivity {
    ListView list_shiksha;
    private AdapterShiksha adapterShiksha;
    ArrayList<Utilities> myitems=new ArrayList<>();
    String class_1="कक्षा 1";
    String class_2="कक्षा 2";
    String class_3="कक्षा 3";
    String class_4="कक्षा 4";
    String class_5="कक्षा 5";
    String class_6="कक्षा 6";
    String class_7="कक्षा 7";
    String class_8="कक्षा 8";
    String class_9="कक्षा 9";
    String class_10="कक्षा 10";
    Bitmap class_1_image;
    Bitmap class_2_image;
    Bitmap class_3_image;
    Bitmap class_4_image;
    Bitmap class_5_image;
    Bitmap class_6_image;
    Bitmap class_7_image;
    Bitmap class_8_image;
    Bitmap class_9_image;
    Bitmap class_10_image;
    Utilities class_1_util=new Utilities();
    Utilities class_2_util=new Utilities();
    Utilities class_3_util=new Utilities();
    Utilities class_4_util=new Utilities();
    Utilities class_5_util=new Utilities();
    Utilities class_6_util=new Utilities();
    Utilities class_7_util=new Utilities();
    Utilities class_8_util=new Utilities();
    Utilities class_9_util=new Utilities();
    Utilities class_10_util=new Utilities();





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shiksha);
        list_shiksha=findViewById(R.id.list_shiksha);
        class_1_image = BitmapFactory.decodeResource(getResources(), R.drawable.claas1);
        class_2_image = BitmapFactory.decodeResource(getResources(), R.drawable.class2);
        class_3_image = BitmapFactory.decodeResource(getResources(), R.drawable.class3);
        class_4_image = BitmapFactory.decodeResource(getResources(), R.drawable.class4);
        class_5_image = BitmapFactory.decodeResource(getResources(), R.drawable.class5);
        class_6_image = BitmapFactory.decodeResource(getResources(), R.drawable.class6);
        class_7_image = BitmapFactory.decodeResource(getResources(), R.drawable.class7);
        class_8_image = BitmapFactory.decodeResource(getResources(), R.drawable.class8);
        class_9_image = BitmapFactory.decodeResource(getResources(), R.drawable.class9);
        class_10_image = BitmapFactory.decodeResource(getResources(), R.drawable.class10);

        class_1_util.setName(class_1);
        class_1_util.setImage(class_1_image);
        class_2_util.setName(class_2);
        class_2_util.setImage(class_2_image);
        class_3_util.setName(class_3);
        class_3_util.setImage(class_3_image);

        class_4_util.setName(class_4);
        class_4_util.setImage(class_4_image);

        class_5_util.setName(class_5);
        class_5_util.setImage(class_5_image);

        class_6_util.setName(class_6);
        class_6_util.setImage(class_6_image);

        class_7_util.setName(class_7);
        class_7_util.setImage(class_7_image);

        class_8_util.setName(class_8);
        class_8_util.setImage(class_8_image);

        class_9_util.setName(class_9);
        class_9_util.setImage(class_9_image);

        class_10_util.setName(class_10);
        class_10_util.setImage(class_10_image);

        myitems.add(class_1_util);
        myitems.add(class_2_util);
        myitems.add(class_3_util);
        myitems.add(class_4_util);
        myitems.add(class_5_util);
        myitems.add(class_6_util);
        myitems.add(class_7_util);
        myitems.add(class_8_util);
        myitems.add(class_9_util);
        myitems.add(class_10_util);






        adapterShiksha =new AdapterShiksha(this,myitems);
        list_shiksha.setAdapter(adapterShiksha);
        list_shiksha.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(myitems.get(i).equals(class_1_util))
                {
                    Intent intent=new Intent(getApplicationContext(),Class1.class);
                    intent.putExtra("class_1","class_1");
                    startActivity(intent);
                }
            }
        });
    }
}
