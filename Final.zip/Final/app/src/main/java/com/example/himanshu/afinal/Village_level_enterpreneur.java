package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class Village_level_enterpreneur extends AppCompatActivity {

    CardView cd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_village_level_enterpreneur);
        cd=(CardView)findViewById(R.id.card_view_dairy);
        cd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dairy();
            }
        });
    }

    public  void dairy()
    {

        Intent intent=new Intent(this,Dairy.class);
        startActivity(intent);
    }
}
