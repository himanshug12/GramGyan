package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class Class1 extends AppCompatActivity {
    CardView hindi;
    CardView maths;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class1);
        hindi=(CardView)findViewById(R.id.card_view_hindi);
        maths=(CardView)findViewById(R.id.card_view_maths);


        maths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Maths();
            }
        });
        hindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Hindi();
            }
        });
    }

    public void Hindi() {
        Intent intent=new Intent(this,Hindi_balakdi.class);
        startActivity(intent);
    }


    public void Maths() {
        Intent intent=new Intent(this,Maths_mult.class);
        startActivity(intent);
    }
}
