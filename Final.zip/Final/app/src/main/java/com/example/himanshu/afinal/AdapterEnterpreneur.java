package com.example.himanshu.afinal;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.himanshu.afinal.R;

import java.util.ArrayList;

public class AdapterEnterpreneur extends BaseAdapter {
    Context mcontext;
    ArrayList<String> items=new ArrayList<>();
    private static LayoutInflater inflater = null;

    public AdapterEnterpreneur(Context mcontext, ArrayList<String> items) {
        this.mcontext = mcontext;
        this.items = items;
        inflater = (LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        String myitem=items.get(i);
        AdapterEnterpreneur.ViewHolderClass viewHolderClass = null;

        if(view==null)
        {
            view =  inflater.inflate(R.layout.enterpreneur_item, null);
            viewHolderClass=new AdapterEnterpreneur.ViewHolderClass(view);
            view.setTag(viewHolderClass);
        }
        else{
            viewHolderClass= (AdapterEnterpreneur.ViewHolderClass) view.getTag();
        }
        if(myitem!=null){
            viewHolderClass.item.setText(myitem);

        }
        return view;


    }


    class ViewHolderClass {

        public TextView item;

        public ViewHolderClass(View v) {
            item = v.findViewById(R.id.item_name);
        }
    }

}
