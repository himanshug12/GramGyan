package com.example.himanshu.afinal;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;



import java.util.ArrayList;



public class AdapterKrishi extends BaseAdapter {

    Context context;
    private static LayoutInflater inflater = null;
    ArrayList<Utilities> utilities=new ArrayList<>();

    public AdapterKrishi(Context context, ArrayList<Utilities> utilities) {
        this.context = context;
        this.utilities = utilities;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return utilities.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Utilities util=utilities.get(i);
        AdapterKrishi.ViewHolderClass viewHolderClass = null;

        if(view==null)
        {
            view =  inflater.inflate(R.layout.krishi_item, null);
            viewHolderClass=new AdapterKrishi.ViewHolderClass(view);
            view.setTag(viewHolderClass);
        }
        else{
            viewHolderClass= (AdapterKrishi.ViewHolderClass) view.getTag();
        }

        if(util!=null)
        {
            viewHolderClass.txtView.setText(util.getName());
            viewHolderClass.circleImageView.setImageBitmap(util.getImage());

        }

        return view;
    }


    class ViewHolderClass {

        public TextView txtView;
        public ImageView circleImageView;

        public ViewHolderClass(View v) {
            txtView=v.findViewById(R.id.txtvw);
            circleImageView=v.findViewById(R.id.circleimg);
        }
    }
}
