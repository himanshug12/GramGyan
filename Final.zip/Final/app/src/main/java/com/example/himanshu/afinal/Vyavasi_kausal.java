package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class Vyavasi_kausal extends AppCompatActivity {

    ListView listView;
    private AdapterEnterpreneur adapterEnterpreneur;
    ArrayList<String> myitems=new ArrayList<>();
    String village_level_enterpreneur="ग्राम स्तर व्यापार";
    String sarkari_yojana="सरकारी योजना";
    String common_service_centre="सार्वजनिक सेवा केन्द्र";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vyavasi_kausal);
        listView=findViewById(R.id.list);

        myitems.add(village_level_enterpreneur);
        myitems.add(sarkari_yojana);
        myitems.add(common_service_centre);



        adapterEnterpreneur=new AdapterEnterpreneur(this,myitems);
        listView.setAdapter(adapterEnterpreneur);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(myitems.get(i).equals(village_level_enterpreneur))
                {
                    Intent intent=new Intent(getApplicationContext(),Village_level_enterpreneur.class);
                    startActivity(intent);
                }
            }
        });
    }
}
