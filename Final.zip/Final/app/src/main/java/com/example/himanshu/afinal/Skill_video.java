package com.example.himanshu.afinal;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class Skill_video extends AppCompatActivity {


        VideoView videoView1;
        Button play1;
        Button pause1;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_skill_video);


            videoView1=(VideoView)findViewById(R.id.vedio2);
            pause1=(Button)findViewById(R.id.tn2);
            play1=(Button)findViewById(R.id.tn1);
            String str="https://firebasestorage.googleapis.com/v0/b/project1-c4719.appspot.com/o/computer%20kaise%20chalate%20hai.mp4?alt=media&token=f1965d8f-f571-47d3-a683-7a1a6458bf43";
            Uri uri=Uri.parse(str);

            videoView1.setVideoURI(uri);
            videoView1.requestFocus();
            videoView1.setMediaController(new MediaController(Skill_video.this));

            play1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    videoView1.start();
                }
            });

            pause1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    videoView1.pause();
                }
            });

        }
    }

