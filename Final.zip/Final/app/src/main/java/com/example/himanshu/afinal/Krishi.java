package com.example.himanshu.afinal;

import android.content.Intent;
import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;



        import java.util.ArrayList;

public class Krishi extends AppCompatActivity {

    AdapterKrishi adapterKrishi;
    ListView listView;
    ArrayList<Utilities> arrayList=new ArrayList<>();
    String bajra="बाजरा";
    String jute="जूट";
    String maize="मक्का";
    String rice="चावल";
    String tea="चाय";
    String wheat="गेहूं";
    Bitmap bajra_image;
    Bitmap jute_image;
    Bitmap maize_image;
    Bitmap rice_image;
    Bitmap tea_image;
    Bitmap wheat_image;
    Utilities bajra_utility=new Utilities();
    Utilities jute_utility=new Utilities();
    Utilities maize_utility=new Utilities();
    Utilities rice_utility=new Utilities();
    Utilities tea_utility=new Utilities();
    Utilities wheat_utility=new Utilities();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_krishi);
        listView = (ListView) findViewById(R.id.list);

        wheat_image = BitmapFactory.decodeResource(getResources(), R.drawable.wheat);
        bajra_image = BitmapFactory.decodeResource(getResources(), R.drawable.bajra);
        jute_image = BitmapFactory.decodeResource(getResources(), R.drawable.jute);
        maize_image = BitmapFactory.decodeResource(getResources(), R.drawable.maize);
        rice_image = BitmapFactory.decodeResource(getResources(), R.drawable.rice);
        tea_image = BitmapFactory.decodeResource(getResources(), R.drawable.tea);
        bajra_utility.setName(bajra);
        bajra_utility.setImage(bajra_image);
        jute_utility.setName(jute);
        jute_utility.setImage(jute_image);
        maize_utility.setName(maize);
        maize_utility.setImage(maize_image);
        rice_utility.setName(rice);
        rice_utility.setImage(rice_image);
        tea_utility.setName(tea);
        tea_utility.setImage(tea_image);
        wheat_utility.setName(wheat);
        wheat_utility.setImage(wheat_image);

        arrayList.add(wheat_utility);
        arrayList.add(bajra_utility);
        arrayList.add(rice_utility);
        arrayList.add(jute_utility);
        arrayList.add(maize_utility);
        arrayList.add(tea_utility);


        adapterKrishi = new AdapterKrishi(this, arrayList);
        listView.setAdapter(adapterKrishi);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(arrayList.get(i).equals(wheat_utility))
                {
                    Intent intent=new Intent(getApplicationContext(),Wheat_crop.class);
                    startActivity(intent);
                }
            }
        });






    }
}

