package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Beti_bachao extends AppCompatActivity {

    TextView link_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beti_bachao);

        link_=(TextView)findViewById(R.id.link);

        link_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                link();
            }
        });
    }
    public void link()
    {
        Intent intent=new Intent(this,Web_Beti.class);
        startActivity(intent);

    }
}
