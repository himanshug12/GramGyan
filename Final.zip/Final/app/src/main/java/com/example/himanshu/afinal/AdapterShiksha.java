package com.example.himanshu.afinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;

public class AdapterShiksha extends BaseAdapter {

    Context mcontext;
    ArrayList<Utilities> utilities=new ArrayList<>();
    private static LayoutInflater inflater = null;

    public AdapterShiksha(Context mcontext, ArrayList<Utilities> items) {
        this.mcontext = mcontext;
        this.utilities = items;
        inflater = (LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return utilities.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {


        Utilities util=utilities.get(i);
        ViewHolderClass viewHolderClass = null;

        if(view==null)
        {
            view = inflater.inflate(R.layout.shiksha_item, null);
            viewHolderClass=new ViewHolderClass(view);
            view.setTag(viewHolderClass);
        }
        else{
            viewHolderClass= (ViewHolderClass) view.getTag();
        }
        if(util!=null){
            viewHolderClass.item.setText(util.getName());
            viewHolderClass.circleImageView.setImageBitmap(util.getImage());


        }


        return view;

    }

    class ViewHolderClass {

        public TextView item;
        public ImageView circleImageView;


        public ViewHolderClass(View v) {
            item = v.findViewById(R.id.txtvw);
            circleImageView=v.findViewById(R.id.circleimg);

        }
    }



}
