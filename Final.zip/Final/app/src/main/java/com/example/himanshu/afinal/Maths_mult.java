package com.example.himanshu.afinal;

        import android.net.Uri;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.MediaController;
        import android.widget.VideoView;

public class Maths_mult extends AppCompatActivity {

    VideoView videoView1;
    Button play1;
    Button pause1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths_mult);


        videoView1=(VideoView)findViewById(R.id.vedio2);
        pause1=(Button)findViewById(R.id.tn2);
        play1=(Button)findViewById(R.id.tn1);
        String str="https://firebasestorage.googleapis.com/v0/b/project1-c4719.appspot.com/o/videoplayback.mp4?alt=media&token=f57f117b-6257-48b5-bec3-365d8f95fb46";
        Uri uri=Uri.parse(str);

        videoView1.setVideoURI(uri);
        videoView1.requestFocus();
        videoView1.setMediaController(new MediaController(Maths_mult.this));

        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView1.start();
            }
        });

        pause1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView1.pause();
            }
        });

    }
}

