package com.example.himanshu.afinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import  com.example.himanshu.afinal.Govt_schemes;

import java.util.ArrayList;

class Adapter_Sarkari_Yojana extends BaseAdapter {
    Context context;
    private static LayoutInflater inflater = null;
    ArrayList<Utilities> utilities=new ArrayList<>();

    public Adapter_Sarkari_Yojana(Context context, ArrayList<Utilities> utilities) {
        this.context = context;
        this.utilities = utilities;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return utilities.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Utilities util=utilities.get(i);
        Adapter_Sarkari_Yojana.ViewHolderClass viewHolderClass = null;

        if(view==null)
        {
            view =  inflater.inflate(R.layout.govt_scheme_item, null);
            viewHolderClass=new Adapter_Sarkari_Yojana.ViewHolderClass(view);
            view.setTag(viewHolderClass);
        }
        else{
            viewHolderClass= (Adapter_Sarkari_Yojana.ViewHolderClass) view.getTag();
        }

        if(util!=null)
        {
            viewHolderClass.txtView.setText(util.getName());
            viewHolderClass.imageView.setImageBitmap(util.getImage());

        }

        return view;
    }

    class ViewHolderClass {

        public TextView txtView;
        public ImageView imageView;

        public ViewHolderClass(View v) {
            txtView=v.findViewById(R.id.txtvw);
            imageView=v.findViewById(R.id.circleimg);
        }
    }


}
