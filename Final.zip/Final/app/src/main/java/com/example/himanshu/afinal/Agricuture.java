package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Agricuture extends AppCompatActivity {

    private ImageView imageView1;
    private  ImageView imageView2;
    private ImageView sarkari_yojna;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agricuture);


        imageView1=(ImageView)findViewById(R.id.expert);
        imageView2=(ImageView)findViewById(R.id.crop);
        sarkari_yojna=(ImageView)findViewById(R.id.sarkar);


        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expert();
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crop();
            }
        });
        sarkari_yojna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sarkar();
            }
        });


    }


    public void expert()
    {
        Intent intent=new Intent(this,Advisor.class);
        startActivity(intent);
    }

    public  void crop()
    {
        Intent intent=new Intent(this,Krishi.class);
        startActivity(intent);

    }
    public void sarkar()
    {

        Intent intent=new Intent(this,Govt_schemes.class);
        startActivity(intent);
    }

}
