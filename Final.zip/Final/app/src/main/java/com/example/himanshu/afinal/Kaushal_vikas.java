package com.example.himanshu.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class Kaushal_vikas extends AppCompatActivity {

    CardView computer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kaushal_vikas);

        computer=(CardView)findViewById(R.id.card_view_computer);
        computer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comp();
            }
        });
    }


    public void comp()
    {
        Intent intent=new Intent(this,Furtherskill.class);
        startActivity(intent);
    }
}
