package com.example.himanshu.afinal;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class Navigation extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener {
    private ImageView img_agri;
    private ImageView img_shiksa;
    private ImageView img_ngo;
    private ImageView  img_skill;
    private ImageView img_govt_scheme;
    private DrawerLayout draweryout;
    private ImageView img_ent;

    private ActionBarDrawerToggle actionBarToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        draweryout = (DrawerLayout) findViewById(R.id.dl);
        actionBarToggle = new ActionBarDrawerToggle(this, draweryout, R.string.open, R.string.close);
        draweryout.addDrawerListener(actionBarToggle);
        img_shiksa=(ImageView)findViewById(R.id.s);
        img_govt_scheme=(ImageView)findViewById(R.id.gov);
        img_agri = (ImageView) findViewById(R.id.agric);
        img_ngo = (ImageView) findViewById(R.id.ngo);
        img_ent = (ImageView) findViewById(R.id.ent);

        img_skill = (ImageView) findViewById(R.id.skill);
        actionBarToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        img_agri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_agri();
            }
        });

        img_ngo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_ngo();
            }
        });

        img_shiksa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_shiksh();
            }
        });

        img_govt_scheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_gov();
            }
        });

        img_skill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_skill();
            }
        });



        img_ent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_ent();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (actionBarToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);



    }



    public void image_ent()
    {
        Intent intent8=new Intent(this,Vyavasi_kausal.class);
        startActivity(intent8);
    }


    public void image_agri() {
        Intent intent = new Intent(this, Agricuture.class);
        startActivity(intent);
    }
    public void image_shiksh() {
        Intent intent2 = new Intent(this, Shiksha.class);
        startActivity(intent2);
    }

    public void image_gov() {
        Intent intent3 = new Intent(this, Govt_schemes.class);
        startActivity(intent3);
    }

    public void image_skill() {
        Intent intent4 = new Intent(this, Kaushal_vikas.class);
        startActivity(intent4);
    }


        public void image_ngo() {
            Intent intent1 = new Intent(this, Ngo.class);
            startActivity(intent1);


        }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        switch (id) {

            case R.id.nav_view:
                Intent log1 = new Intent(this, Navigation.class);
                startActivity(log1);
                break;
            case R.id.login:
                Intent log = new Intent(this, Login.class);
                startActivity(log);
                break;
            case R.id.profile:
                Intent pro = new Intent(this, Profil.class);
                startActivity(pro);
                break;
            case R.id.events:
                Intent eve = new Intent(this, Events.class);
                startActivity(eve);
                break;
            case R.id.signup:
                Intent sig = new Intent(this, Signup.class);
                startActivity(sig);
                break;
            case R.id.contact:
                Intent con = new Intent(this, contact.class);
                startActivity(con);
                break;

        }

        DrawerLayout drawerLayout=(DrawerLayout)findViewById(R.id.dl);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;


    }
}








