package com.example.himanshu.afinal;

import android.graphics.Bitmap;

public class Utilities {
    String name;
    Bitmap image;

    public Utilities(String name, Bitmap image) {
        this.name = name;
        this.image = image;
    }

    public Utilities() {
    }

    public String getName() {
        return name;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }
}
