package com.example.himanshu.afinal;


import android.app.ProgressDialog;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class Hindi_balakdi extends AppCompatActivity {

    VideoView videoView;
    Button play;
    Button pause;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hindi_balakdi);


        videoView=(VideoView)findViewById(R.id.vedio1);
        pause=(Button)findViewById(R.id.btn2);
        play=(Button)findViewById(R.id.btn1);
        String str="https://firebasestorage.googleapis.com/v0/b/project1-c4719.appspot.com/o/videoplayback%20(1).mp4?alt=media&token=ebade258-1e26-4cb9-a609-bab2bd19e79e";
        Uri uri=Uri.parse(str);

        videoView.setVideoURI(uri);
        videoView.requestFocus();
        videoView.setMediaController(new MediaController(Hindi_balakdi.this));


        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView.start();
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView.pause();
            }
        });

    }
}
